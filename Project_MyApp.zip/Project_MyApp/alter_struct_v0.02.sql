/*==============================================================*/
/* DBMS name:      PostgreSQL 9.x                               */
/* Created on:     4/4/2018 10:47:42 AM                         */
/*==============================================================*/


alter table pengguna
   add column username VARCHAR(20);

alter table pengguna
   add column password password;

